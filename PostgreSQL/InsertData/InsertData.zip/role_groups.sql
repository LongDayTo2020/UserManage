insert into public.role_groups (id, name, create_time, create_user, update_time, update_user)
values  (1, 'counter_staff', '2023-06-19 15:20:20.676598', '', null, null),
        (2, 'general_public', '2023-06-19 15:20:39.934568', '', null, null);