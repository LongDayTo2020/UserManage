insert into public.permissions (id, name, create_time, create_user, update_time, update_user)
values  (1, 'borrow_book', '2023-06-19 15:11:52.180600', '', null, null),
        (2, 'maintain_book', '2023-06-19 15:12:11.315983', '', null, null),
        (3, 'query_book', '2023-06-19 15:12:20.684682', '', null, null);