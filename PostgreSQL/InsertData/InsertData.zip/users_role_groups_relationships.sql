insert into public.users_role_groups_relationships (user_id, role_group_id, create_time, create_user, update_time, update_user)
values  (2, 2, '2023-06-19 16:15:36.586566', '', null, null),
        (3, 2, '2023-06-19 16:15:41.051703', '', null, null),
        (4, 1, '2023-06-19 16:15:54.847013', '', null, null),
        (5, 1, '2023-06-19 16:15:58.412652', '', null, null);