insert into public.roles_role_groups_relationships (role_id, role_group_id, create_time, create_user, update_time, update_user)
values  (1, 2, '2023-06-20 11:10:15.757965', '', null, null),
        (1, 1, '2023-06-20 11:10:34.184308', '', null, null),
        (2, 1, '2023-06-20 11:10:37.522260', '', null, null);