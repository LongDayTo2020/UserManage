insert into public.users (id, name, account, mail, phone, password, birthday, create_time, create_user, update_time, update_user)
values  (2, '民眾A', 'peopleA', 'peopleA@mail.com', '0912345678', 'peopleA', '2020-01-01 00:00:00.000000', '2023-06-19 14:58:23.776246', '', null, null),
        (3, '民眾B', 'peopleB', 'peopleB@mail.com', '0912345678', 'peopleB', '2022-01-01 00:00:00.000000', '2023-06-19 15:00:46.146020', '', null, null),
        (4, '櫃台B', 'counterB', 'counterB@mail.com', '0912345678', 'counterB', '2022-01-01 00:00:00.000000', '2023-06-19 15:02:55.534879', '', null, null),
        (5, '櫃台A', 'counterA', 'counterA@mail.com', '0912345678', 'counterA', '2022-01-01 00:00:00.000000', '2023-06-19 15:03:06.070742', '', null, null);