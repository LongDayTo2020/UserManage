insert into public.roles (id, name, create_time, create_user, update_time, update_user)
values  (1, 'book_user', '2023-06-19 15:13:31.161292', '', null, null),
        (2, 'book_manager', '2023-06-19 15:14:32.962518', '', null, null);