insert into public.roles_permissions_relationships (role_id, permissions_id, is_create, is_update, is_read, is_delete, is_verify, create_time, create_user, update_time, update_user)
values  (1, 2, 1, 1, 1, 1, 1, '2023-06-19 15:42:09.010761', '', null, null),
        (1, 3, 1, 1, 1, 1, 1, '2023-06-19 15:42:48.819934', '', null, null),
        (2, 1, 1, 1, 1, 1, 1, '2023-06-19 15:43:20.133768', '', null, null),
        (2, 2, 1, 1, 1, 1, 1, '2023-06-19 15:43:23.174033', '', null, null);